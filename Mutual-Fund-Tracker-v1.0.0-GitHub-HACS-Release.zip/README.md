# Mutual Fund Tracker

**Indian mutual-fund portfolio tracking for Home Assistant.**

Mutual Fund Tracker combines a Home Assistant app with a dedicated Home Assistant integration. It tracks Indian mutual-fund holdings, SIPs, transactions, NAV-based valuation, returns and XIRR, and exposes the results to Home Assistant.

> **India only.** The project is designed for Indian mutual funds, CAMS/KFintech statements, AMFI NAV data, NSE trading-day information and Asia/Kolkata (IST).

**Stable release: v1.0.0**

## What is included

| Component | What it does | Install from |
|---|---|---|
| **Mutual Fund Tracker app** | Portfolio database, NAV refresh, SIP processing, statement import, web UI and REST API | Home Assistant **Apps** / Add-ons repository |
| **Mutual Fund Tracker integration** | Home Assistant sensors, controls, status entities and the custom card endpoint | **HACS** or manual `custom_components` install |
| **Mutual Fund Tracker card** | Dashboard view of portfolio and fund metrics | Included with the integration |

**Install the app first.** The integration is the Home Assistant-facing client of the app.

## Features

- Multiple investor profiles and multiple funds per investor
- SIP schedules, historical transactions and portfolio balances
- Latest and historical NAV handling using AMFI data
- Daily, monthly and yearly return calculations
- Portfolio XIRR
- Recent SIP reconciliation during statement import
- Delayed-NAV SIP handling
- NSE today/tomorrow/trading-day status
- NIFTY 50 status in the app
- Light/dark web UI
- Custom Lovelace dashboard card
- PNG portfolio export
- Home Assistant entities for portfolio values, returns, SIP status and NAV refresh status

## Installation in Home Assistant

### 1. Install the Mutual Fund Tracker app

Add this repository to the Home Assistant **App repository** list:

```text
https://github.com/sheminasalam/mutual-fund-tracker
```

Home Assistant requires an app repository to provide a root `repository.yaml`; this repository includes one. citeturn844359search0

Then install **Mutual Fund Tracker**, start it, and open the app Web UI. The app is stored in `mutual-fund-tracker-src/` and its `config.yaml` contains the app metadata.

### 2. Install the Home Assistant integration with HACS

The repository is also structured as a HACS integration repository: `custom_components/mutual_fund_tracker/` is at the repository root and the repository contains a root `hacs.json`. HACS requires a public GitHub repository with a README and a root `hacs.json`. When GitHub releases are used, HACS uses the published release tag as the remote version.

In HACS:

1. Open **HACS → Integrations**.
2. Add this URL as a **Custom repository** with category **Integration** if it is not already listed:
   `https://github.com/sheminasalam/mutual-fund-tracker`
3. Install **Mutual Fund Tracker**.
4. Restart Home Assistant.
5. Go to **Settings → Devices & services → Add Integration** and select **Mutual Fund Tracker**.

The integration uses a config flow and declares `config_flow: true` in its manifest. Home Assistant's current integration requirements call for a matching `config_flow.py` and `config_flow: true` in the manifest. citeturn979619search0turn979619search1

### 3. Add the dashboard card

The custom Lovelace card is included with the integration. The app installs/serves the card file, and the integration exposes the card endpoint. Configure it from your Home Assistant dashboard after the integration is installed.

## Importing your mutual-fund statement

The import workflow is intentionally conservative. Use a **fresh, detailed CAMS/KFintech consolidated statement**, preferably generated today. Imports are limited to statements whose coverage end date is within the last 10 days.

### Quick workflow

**A. Open Import JSON** → **B. Copy the prompt** → **C. Generate a detailed consolidated statement** → **D. Remove the PDF password** → **E. Give the prompt + unlocked PDF to your AI assistant** → **F. Save the generated JSON** → **G. Import and review the preview**.

### Step-by-step with screenshots

#### 1. Open Import JSON

Open the **+** menu in the app header and choose **Import JSON**.

![Open Import JSON](mutual-fund-tracker-src/docs/images/import-menu.png)

#### 2. Copy the exact AI prompt

Click **Copy AI conversion prompt** in the Import window.

![Copy AI prompt](mutual-fund-tracker-src/docs/images/copy-ai-prompt.png)

#### 3. Request the consolidated statement

Use the CAMS/KFintech consolidated statement service with a **Detailed** statement and **Specific Period**. The recommended full-history request is:

- From: `01-Jan-2000`
- To: today's date
- Folio listing: **Without zero balance folios**

Use the email linked to your mutual-fund account. The password is only for statement generation/download. **Do not send that password to an AI assistant. Unlock the PDF first.**

![Recommended statement settings](mutual-fund-tracker-src/docs/images/cams-request-form.png)

#### 4. Convert the unlocked statement to JSON

Paste the copied prompt into your AI assistant and upload the password-removed PDF. Let the AI read the complete statement before it returns the compact JSON.

![AI upload example](mutual-fund-tracker-src/docs/images/ai-upload-example.png)

#### 5. Import and review

Choose the resulting `.json` file in the app. Review investor matching, warnings and recent SIP decisions before confirming the import. Treat the generated JSON as untrusted input—the app validates it before writing to the database.

For the complete import rules and JSON schema, see the [full application guide](mutual-fund-tracker-src/README.md), [AI import prompt](mutual-fund-tracker-src/AI_IMPORT_PROMPT.md), and [import schema](mutual-fund-tracker-src/IMPORT_SCHEMA.json).

## Home Assistant entities

The integration exposes portfolio sensors including:

- Total Value
- Total Invested
- Total Profit and Total Profit %
- Daily / Monthly / Yearly Change
- Portfolio XIRR
- Fund Count

Status/control entities include:

- NSE Today
- NSE Tomorrow
- NSE Trading
- NSE Yesterday Status
- NAV Refresh Error
- SIP Executed Today
- Delayed NAV Update
- Refresh NAV
- Export Portfolio PNG

## Updating

The stable release line starts at **v1.0.0**. Future fixes should be released with normal semantic-version increments such as `1.0.1` for bug fixes and `1.1.0` for backward-compatible feature releases. Keep the app `config.yaml` version, app manifest version, PWA manifest version and custom-integration manifest version aligned.

## Documentation

- [Complete application guide](mutual-fund-tracker-src/README.md)
- [Application documentation](mutual-fund-tracker-src/DOCS.md)
- [AI import prompt](mutual-fund-tracker-src/AI_IMPORT_PROMPT.md)
- [Import schema](mutual-fund-tracker-src/IMPORT_SCHEMA.json)
- [Home Assistant integration guide](custom_components/mutual_fund_tracker/README.md)
- [Changelog](mutual-fund-tracker-src/CHANGELOG.md)

## Support

Please report bugs and feature requests through [GitHub Issues](https://github.com/sheminasalam/mutual-fund-tracker/issues). When reporting an issue, include the app version, Home Assistant version, relevant logs and the reproduction steps. **Never include CAMS/KFintech passwords, PAN details, account numbers or private statement PDFs in public issues.**

## License

MIT License. See [LICENSE](LICENSE).
